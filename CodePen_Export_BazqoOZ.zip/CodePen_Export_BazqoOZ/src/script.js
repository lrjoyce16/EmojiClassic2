<body>


document.write(Date);

document.getElementById(id).style.property = new style

alert(Hi, how are you doing?);

</body>